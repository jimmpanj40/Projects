/*
 * mpu.h
 *
 *  Created on: May 26, 2021
 *      Author: sydxrey
 */

#ifndef INC_MPU_H_
#define INC_MPU_H_

#include "stm32f7xx_hal.h"

void MPU_Init();


#endif /* INC_MPU_H_ */
