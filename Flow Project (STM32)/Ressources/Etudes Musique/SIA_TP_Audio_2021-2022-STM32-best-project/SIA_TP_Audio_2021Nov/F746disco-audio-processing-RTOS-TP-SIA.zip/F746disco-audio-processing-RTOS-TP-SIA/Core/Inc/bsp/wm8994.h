/*
 * wm8994.h --- WM8994 audio codec driver
 *
 *  Created on: May 14, 2021
 *      Author: sydxrey
 */

#ifndef INC_WM8994_H_
#define INC_WM8994_H_

#include "stdint.h"


/******************************************************************************/
/***************************  Codec User defines ******************************/
/******************************************************************************/
/* Codec output DEVICE */
#define OUTPUT_DEVICE_SPEAKER                 ((uint16_t)0x0001)
#define OUTPUT_DEVICE_HEADPHONE               ((uint16_t)0x0002)
#define OUTPUT_DEVICE_BOTH                    ((uint16_t)0x0003)
#define OUTPUT_DEVICE_AUTO                    ((uint16_t)0x0004)
#define INPUT_DEVICE_DIGITAL_MICROPHONE_1     ((uint16_t)0x0100)
#define INPUT_DEVICE_DIGITAL_MICROPHONE_2     ((uint16_t)0x0200)
#define INPUT_DEVICE_INPUT_LINE_1             ((uint16_t)0x0300)
#define INPUT_DEVICE_INPUT_LINE_2             ((uint16_t)0x0400)
#define INPUT_DEVICE_DIGITAL_MIC1_MIC2        ((uint16_t)0x0800)

/* Volume Levels values */
#define DEFAULT_VOLMIN                0x00
#define DEFAULT_VOLMAX                0xFF
#define DEFAULT_VOLSTEP               0x04

#define AUDIO_PAUSE                   0
#define AUDIO_RESUME                  1

/* Codec POWER DOWN modes */
#define CODEC_PDWN_HW                 1
#define CODEC_PDWN_SW                 2

/* MUTE commands */
#define AUDIO_MUTE_ON                 1
#define AUDIO_MUTE_OFF                0

/* AUDIO FREQUENCY */
#define AUDIO_FREQUENCY_192K          ((uint32_t)192000)
#define AUDIO_FREQUENCY_96K           ((uint32_t)96000)
#define AUDIO_FREQUENCY_48K           ((uint32_t)48000)
#define AUDIO_FREQUENCY_44K           ((uint32_t)44100)
#define AUDIO_FREQUENCY_32K           ((uint32_t)32000)
#define AUDIO_FREQUENCY_22K           ((uint32_t)22050)
#define AUDIO_FREQUENCY_16K           ((uint32_t)16000)
#define AUDIO_FREQUENCY_11K           ((uint32_t)11025)
#define AUDIO_FREQUENCY_8K            ((uint32_t)8000)

#define VOLUME_CONVERT(Volume)        (((Volume) > 100)? 63:((uint8_t)(((Volume) * 63) / 100)))
#define VOLUME_IN_CONVERT(Volume)     (((Volume) >= 100)? 239:((uint8_t)(((Volume) * 240) / 100)))

/******************************************************************************/
/****************************** REGISTER MAPPING ******************************/
/******************************************************************************/
/**
  * @brief  WM8994 ID
  */
#define  WM8994_ID    0x8994

/**
  * @brief Device ID Register: Reading from this register will indicate device
  *                            family ID 8994h
  */
#define WM8994_CHIPID_ADDR                  0x00


/*------------------------------------------------------------------------------
                           Audio Codec functions
------------------------------------------------------------------------------*/
/* High Layer codec functions */
uint32_t wm8994_Init(uint16_t OutputInputDevice, uint8_t Volume, uint32_t AudioFreq);
uint32_t wm8994_ReadID();
uint32_t wm8994_Play(uint16_t* pBuffer, uint16_t Size);
uint32_t wm8994_Pause();
uint32_t wm8994_Resume();
uint32_t wm8994_Stop(uint32_t Cmd);
uint32_t wm8994_SetVolume(uint8_t Volume);
uint32_t wm8994_SetMute(uint32_t Cmd);
uint32_t wm8994_Mute();
uint32_t wm8994_Unmute();
uint32_t wm8994_SetOutputMode(uint8_t Output);
uint32_t wm8994_SetFrequency(uint32_t AudioFreq);
uint32_t wm8994_Reset();



#endif /* INC_WM8994_H_ */
