/*
 * test.h
 *
 *  Created on: May 14, 2021
 *      Author: sydxrey
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_

#include "main.h"

// uncomment to allocate data for testing purpose:
//#define ALLOCATE_TEST_DATA

void test();

#endif /* INC_TEST_H_ */
