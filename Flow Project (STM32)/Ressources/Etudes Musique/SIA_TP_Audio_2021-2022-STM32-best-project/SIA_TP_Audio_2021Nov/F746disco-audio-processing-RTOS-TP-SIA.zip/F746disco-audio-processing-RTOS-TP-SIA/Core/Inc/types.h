/*
 * types.h
 *
 *  Created on: May 25, 2021
 *      Author: sydxrey
 */

#ifndef INC_TYPES_H_
#define INC_TYPES_H_

typedef enum {
	false,
	true
} boolean_t;


#endif /* INC_TYPES_H_ */
